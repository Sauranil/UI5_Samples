sap.ui.define([
	"UI5_/TableFunctions/test/unit/controller/View1.controller"
], function () {
	"use strict";
});